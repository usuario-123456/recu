#include "ChatControlMessageElement.h"

ChatControlMessageElement::ChatControlMessageElement()
	: height(0)
{
}

ChatControlMessageElement::~ChatControlMessageElement()
{
}

int ChatControlMessageElement::getHeight() const
{
	return height;
}
