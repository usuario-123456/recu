#pragma once

#include <map>

#include "../../../../resources/resource.h"

extern std::map<int, int> characterToResource;
