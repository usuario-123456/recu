#pragma once

#include <string>

std::string formatTimestamp(long long timestamp);
std::string formatTimestampIso(long long timestamp);
std::string formatDate(long long timestamp);
bool isSameDay(long long timestamp1, long long timestamp2);
