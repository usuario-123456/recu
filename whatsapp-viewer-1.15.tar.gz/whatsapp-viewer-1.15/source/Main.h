#pragma once

#include <vector>
#include <string>

void entryPoint(const std::vector<std::string *> arguments);
