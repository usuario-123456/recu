#pragma once

void decryptWhatsappDatabase14(const std::string &filename, const std::string &filenameDecrypted, const std::string &keyFilename);
