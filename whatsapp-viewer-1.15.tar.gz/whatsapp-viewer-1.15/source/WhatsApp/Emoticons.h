#pragma once

int getSmiley(int character);
