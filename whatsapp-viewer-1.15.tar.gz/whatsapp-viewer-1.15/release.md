Just a checklist for myself I have to do manually for a release.

- Increase version in *resources/Resources.rc*
  - FileVersion
  - ProductVersion
  - FILEVERSION
  - PRODUCTVERSION
- `build-release.cmd`
- Update changelog
- `git tag v1.XX` && `git push origin v1.XX`
- Close Github Milestone
- Upload binary to Github Release
